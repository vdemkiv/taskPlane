# v3 Phase 3 — engineering review

Ten tasks across five waves (R-0007 engine correctness, R-0008 routing
precision, R-0009 host portability, R-0010 docs currency, R-0011 hygiene),
followed by the R-0012 performance work the human gated ahead of sign-off.

## Verdict

Recommend pass. Every regression-class finding is resolved with a named
commit and a regression test. Thirteen findings classed pre-existing or
observation are deferred to the Phase 4 backlog by explicit human decision
("keep full rigor everywhere" — depth was not reduced anywhere; these are
items outside this phase's diff or below its blocking bar).

## What the review found that no test battery caught first

Two HIGH regressions, both introduced by hardening and both invisible to the
suite: the A5 machinery warn-row exemption was spoofable by the findings
author, and E5's slot-charset refusal fired before the dispatch rail was
chosen, denying the mandatory Task path and bricking Codex. Both are fixed
and pinned.

The plan-ordering gate added in this phase could synthesize an unsatisfiable
dependency cycle from two catch-all scopes, dead-ending an already-planned
loop at the human approval gate with no bypass. Fixed; the Phase 2 sequencing
gap the gate exists for is still caught, pinned by test.

B5's fixture discount had a third hole neither prior guard closed: one test
tree importing another vouched for it. A fixture cannot be its own witness.

## Performance (R-0012)

The human escalated loop performance to blocking before sign-off. Measured
against mid-July: per-task cost had grown about thirteenfold, as the product
of four independent growths, none of them individually wrong. Three fixes
landed — a content-keyed suite result so identical bytes are tested once, an
engine-computed evidence bundle so evaluators stop rebuilding known facts by
hand, and a CI ratchet that pins what the engine mandates per task so
governance carries a budget like everything else.

No gate was loosened to achieve it. Two got stricter: a cited suite run is
now a traced fact with a key and an origin, and adding a proof obligation
now trips a ratchet that makes you say so on the record.

## Bookkeeping

One em-fix (the A5 residual spoof closure and its tests) was swept into the
P1 commit by `git add -A`. The work and its tests are correct and present;
only the commit attribution is wrong. Recorded rather than rewritten.
