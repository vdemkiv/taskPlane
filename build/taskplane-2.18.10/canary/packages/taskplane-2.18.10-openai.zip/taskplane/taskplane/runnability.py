"""Can the build and the tests actually RUN here? Probe once, tell everyone.

Found by the karpenter field report (aws/karpenter-provider-aws#9464): six
lens agents were dispatched in parallel and SIX of them independently spent
actions discovering that `go test ./...` could not run in that sandbox. Each
one tried it, read the failure, reasoned about whether the failure was the
PR's fault, and only then fell back to reading code — six times, from a cold
start, for one fact that was true of the environment and not of the diff.

That is the shape of waste this module removes. Runnability is a property of
the CHECKOUT, not of the lens: it is knowable once, cheaply, before any agent
is dispatched, and it belongs in every brief as a stated fact.

Three design rules, each of which a previous attempt got wrong:

  1. PROBE, DO NOT RUN. The probe must never be the test suite. Every probe
     here is bounded (a timeout, a cheap subcommand) and answers only "would
     the real command get off the ground", never "does it pass".
  2. CACHE PER TREE STATE, NOT PER SESSION. The verdict is keyed by the
     manifests that decide it plus the PATH that resolves the toolchain, so
     `go install`-ing the missing toolchain mid-review re-probes, while six
     agents in the same second share one answer.
  3. STATE IT, DO NOT ENFORCE IT. Nothing here blocks anything. A lens that
     needs a dynamic check it cannot run says so in its finding; it does not
     get denied, and no gate consults this file. Enforcement lives in tp.py
     and the hooks (see the deletability contract) — never here, and never
     in loop.py.
"""
import hashlib
import json
import os
import shutil
import subprocess
import sys

# Verdicts. "runs" is the only optimistic one and it is deliberately weak:
# the probe proves the command starts, not that the suite is green.
RUNS = "runs"
UNAVAILABLE = "unavailable"     # the toolchain itself is not on PATH
BROKEN = "broken"               # toolchain present, probe failed (deps, etc.)
UNKNOWN = "unknown"             # probe timed out or could not be attempted

CACHE_NAME = "runnability.json"
DEFAULT_TIMEOUT = 25

# Ordered so the summary line names the repo's primary toolchain first.
SPECS = (
    {"id": "go", "markers": ("go.mod",), "tool": "go",
     "test_cmd": "go test ./...",
     "probe": ("go", "list", "./..."),
     # `go list` resolves the module graph exactly like `go test` does, so a
     # sandbox with no module cache and no network fails HERE, in seconds,
     # instead of failing once per agent halfway through a review.
     },
    {"id": "typescript", "markers": ("tsconfig.json",), "tool": "node",
     "test_cmd": "npm exec tsc -- --noEmit",
     "probe": ("node", "node_modules/typescript/bin/tsc", "--version"),
     "needs_dir": "node_modules",
     "needs_dir_reason": "dependencies are not installed (no `node_modules`)",
     "needs_file": "node_modules/typescript/bin/tsc",
     "needs_file_reason": "the local TypeScript compiler is not installed"},
    {"id": "node", "markers": ("package.json",), "tool": "node",
     "test_cmd": "npm test",
     "probe": ("node", "--version"),
     "needs_dir": "node_modules",
     "needs_dir_reason": "dependencies are not installed (no `node_modules`)"},
    {"id": "python", "markers": ("pyproject.toml", "requirements.txt",
                                 "setup.py", "setup.cfg", "tox.ini",
                                 "pytest.ini"),
     "tool": "python3", "test_cmd": "pytest",
     "probe": ("python3", "-c", "import pytest")},
    {"id": "rust", "markers": ("Cargo.toml",), "tool": "cargo",
     "test_cmd": "cargo test",
     "probe": ("cargo", "metadata", "--no-deps", "--offline",
               "--format-version", "1")},
    {"id": "maven", "markers": ("pom.xml",), "tool": "mvn",
     "test_cmd": "mvn test", "probe": ("mvn", "--version")},
    {"id": "gradle", "markers": ("build.gradle", "build.gradle.kts"),
     "tool": "gradle", "test_cmd": "gradle test",
     "probe": ("gradle", "--version")},
)

_BY_ID = {s["id"]: s for s in SPECS}

_LANGUAGE_TOOLCHAINS = {
    "go": "go",
    "python": "python",
    "typescript": "typescript",
}

_LANGUAGE_QUALITY_CHECKS = {
    "python": (
        {"id": "lint", "module": "ruff", "arguments": ("check",)},
        {"id": "format", "module": "ruff",
         "arguments": ("format", "--check")},
        {"id": "strict-typing", "module": "mypy",
         "arguments": ("--strict", "--config-file", "pyproject.toml")},
        {"id": "security-static", "module": "bandit",
         "arguments": ("-r", "taskplane", "-ll")},
    ),
}


def enabled(*, authority: dict | None = None) -> bool:
    """A receipted `TASKPLANE_RUNNABILITY=off` skips the probe entirely."""
    from taskplane.settings import load_settings
    settings = load_settings(environment=os.environ, authority=authority)
    return settings.runtime.runnability == "probe"


def detect(root: str) -> list:
    """Which toolchains this checkout declares, in SPECS order."""
    out = []
    for spec in SPECS:
        for m in spec["markers"]:
            if os.path.exists(os.path.join(root, m)):
                out.append(spec["id"])
                break
    return out


def _markers_present(root: str, spec) -> list:
    return [m for m in spec["markers"]
            if os.path.exists(os.path.join(root, m))]


def fingerprint(root: str) -> str:
    """What the verdict actually depends on: which manifests exist and their
    size/mtime, plus the PATH that resolves the toolchains. Installing a
    toolchain or editing a manifest invalidates; six agents in one wave do
    not."""
    h = hashlib.sha1()
    for spec in SPECS:
        for m in spec["markers"]:
            p = os.path.join(root, m)
            try:
                st = os.stat(p)
            except OSError:
                continue
            h.update(f"{m}:{st.st_size}:{st.st_mtime_ns}\n".encode("utf-8"))
        for dependency in (spec.get("needs_dir"), spec.get("needs_file")):
            if not dependency:
                continue
            path = os.path.join(root, dependency)
            try:
                st = os.stat(path)
                present = f"{dependency}:{st.st_size}:{st.st_mtime_ns}\n"
            except OSError:
                present = f"{dependency}:missing\n"
            h.update(present.encode("utf-8"))
    h.update(("PATH=" + (os.environ.get("PATH") or "")).encode("utf-8"))
    return h.hexdigest()[:16]


def _probe_one(root: str, spec, timeout: int) -> dict:
    tool = spec["tool"]
    entry = {"id": spec["id"], "tool": tool, "command": spec["test_cmd"],
             "markers": _markers_present(root, spec)}
    if shutil.which(tool) is None:
        entry["verdict"] = UNAVAILABLE
        entry["detail"] = f"`{tool}` is not on PATH"
        return entry
    need = spec.get("needs_dir")
    if need and not os.path.isdir(os.path.join(root, need)):
        entry["verdict"] = BROKEN
        entry["detail"] = spec.get("needs_dir_reason",
                                   f"`{need}` is missing")
        return entry
    need_file = spec.get("needs_file")
    if need_file and not os.path.isfile(os.path.join(root, need_file)):
        entry["verdict"] = BROKEN
        entry["detail"] = spec.get(
            "needs_file_reason", f"`{need_file}` is missing")
        return entry
    try:
        # encoding= is mandatory here: text=True alone decodes with the
        # ambient locale, which is ascii on a bare CI runner (v2.9.0 CI red).
        proc = subprocess.run(list(spec["probe"]), cwd=root,
                              stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                              text=True, encoding="utf-8", errors="replace",
                              timeout=timeout)
    except subprocess.TimeoutExpired:
        entry["verdict"] = UNKNOWN
        entry["detail"] = (f"probe `{' '.join(spec['probe'])}` did not finish "
                           f"in {timeout}s")
        return entry
    except OSError as e:
        entry["verdict"] = UNKNOWN
        entry["detail"] = f"probe could not start ({e.__class__.__name__})"
        return entry
    if proc.returncode == 0:
        entry["verdict"] = RUNS
        entry["detail"] = f"`{' '.join(spec['probe'])}` succeeded"
        return entry
    entry["verdict"] = BROKEN
    entry["detail"] = _first_useful_line(proc.stdout) or (
        f"`{' '.join(spec['probe'])}` exited {proc.returncode}")
    return entry


def _first_useful_line(text: str) -> str:
    for raw in (text or "").splitlines():
        line = raw.strip()
        if line and not line.startswith("#"):
            return line[:220]
    return ""


def probe(root: str, *, timeout: int = DEFAULT_TIMEOUT,
          only: list | None = None) -> dict:
    """Probe every declared toolchain. Never raises — a probe that cannot be
    performed is UNKNOWN, and an unknown verdict is still worth stating."""
    ids = [i for i in detect(root) if not only or i in only]
    checks = [_probe_one(root, _BY_ID[i], timeout) for i in ids]
    return {"fingerprint": fingerprint(root), "checks": checks,
            "summary": summary(checks)}


def probe_language_toolchains(root: str, languages, *,
                              timeout: int = DEFAULT_TIMEOUT) -> list[dict]:
    """Probe exactly the impacted registered implementation languages.

    This is separate from the checkout-wide convenience probe: evaluator
    evidence cannot let a missing manifest silently erase a changed language.
    A caller receives one check per requested language or a typed error.
    """
    requested = [str(item) for item in languages or []]
    if not requested:
        raise ValueError("impacted language toolchain inventory is empty")
    if len(requested) != len(set(requested)):
        raise ValueError("duplicate impacted language toolchain mapping")
    unsupported = [name for name in requested
                   if name not in _LANGUAGE_TOOLCHAINS]
    if unsupported:
        raise ValueError(
            "unsupported impacted language toolchain: "
            + ", ".join(sorted(unsupported))
        )
    checkout_fingerprint = fingerprint(root)
    rows = []
    for language in sorted(requested):
        spec = _BY_ID[_LANGUAGE_TOOLCHAINS[language]]
        row = _probe_one(root, spec, timeout)
        row["language"] = language
        row["fingerprint"] = checkout_fingerprint
        rows.append(row)
    return rows


def probe_language_quality_toolchains(root: str, languages, *,
                                      timeout: int = DEFAULT_TIMEOUT) -> list[dict]:
    """Resolve every hard quality gate required by the pinned language guide.

    This is an availability probe, not a quality run.  Each returned argv is
    executable as-is once the caller appends its candidate-bound selectors.
    Missing lint, format, strict typing, or security tooling remains explicit
    so Evaluate can fail closed before dispatching an evidence producer.
    """
    requested = [str(item) for item in languages or []]
    if not requested or len(requested) != len(set(requested)):
        raise ValueError("impacted language quality mapping is empty or duplicate")
    unsupported = sorted(set(requested) - set(_LANGUAGE_QUALITY_CHECKS))
    if unsupported:
        raise ValueError(
            "unsupported impacted language quality toolchain: " +
            ", ".join(unsupported))
    rows = []
    for language in sorted(requested):
        checks = []
        for spec in _LANGUAGE_QUALITY_CHECKS[language]:
            module = spec["module"]
            argv = [sys.executable, "-m", module, *spec["arguments"]]
            try:
                proc = subprocess.run(
                    [sys.executable, "-m", module, "--version"], cwd=root,
                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                    text=True, encoding="utf-8", errors="replace",
                    timeout=timeout)
            except subprocess.TimeoutExpired:
                verdict, version = UNKNOWN, "version probe timed out"
            except OSError as exc:
                verdict = UNKNOWN
                version = f"version probe could not start ({exc.__class__.__name__})"
            else:
                verdict = RUNS if proc.returncode == 0 else UNAVAILABLE
                version = _first_useful_line(proc.stdout) or \
                    f"module {module} is unavailable"
            checks.append({
                "id": spec["id"], "argv": argv, "tool": module,
                "tool_version": version, "verdict": verdict,
            })
        material = json.dumps(
            checks, sort_keys=True, separators=(",", ":"),
            ensure_ascii=True).encode("utf-8")
        rows.append({
            "language": language,
            "fingerprint": hashlib.sha256(material).hexdigest(),
            "checks": checks,
        })
    return rows


def summary(checks: list) -> str:
    """One line, safe to put in a headline or in `meta.tests`."""
    if not checks:
        return "no build/test toolchain detected"
    bad = [c for c in checks if c.get("verdict") != RUNS]
    if not bad:
        return " · ".join(f"{c['command']} runs" for c in checks)
    first = bad[0]
    line = f"{first['command']} could not run — {first.get('detail', '')}"
    if len(bad) > 1:
        line += f" (+{len(bad) - 1} more toolchain"
        line += "s)" if len(bad) > 2 else ")"
    return line.strip().rstrip("—").strip()


def can_run_tests(result: dict) -> bool:
    checks = (result or {}).get("checks") or []
    return bool(checks) and all(c.get("verdict") == RUNS for c in checks)


def evidence_record(result: dict | None) -> dict:
    """Stable envelope input, excluding cache-observation annotations.

    ``cached`` describes how this process obtained the record, not whether
    the target can run.  Including it made first-use and later lenses cite
    different context fingerprints for the same probe.
    """
    row = dict(result or {})
    for key in ("cached", "cache_hit", "loaded_at", "observed_at"):
        row.pop(key, None)
    row["checks"] = sorted(
        [dict(check) for check in (row.get("checks") or [])],
        key=lambda check: (str(check.get("id", "")),
                           str(check.get("command", ""))))
    return row


# ------------------------------------------------------------------ cache

def _cache_path(workspace: str) -> str:
    import taskplane_lite as tp
    return os.path.join(tp.tp_dir(workspace), CACHE_NAME)


def cached(workspace: str, root: str | None = None) -> dict | None:
    """The stored verdict IF it still describes this tree, else None."""
    root = root or workspace
    try:
        with open(_cache_path(workspace), encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        return None
    if not isinstance(data, dict) or data.get("fingerprint") != fingerprint(root):
        return None
    return data


def store(workspace: str, result: dict) -> dict:
    path = _cache_path(workspace)
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(result, f, indent=2, sort_keys=True)
    except OSError:
        pass          # a cache that cannot be written must not fail a review
    return result


def probe_once(workspace: str, root: str | None = None, *,
               timeout: int = DEFAULT_TIMEOUT, refresh: bool = False,
               settings_authority: dict | None = None) -> dict:
    """The entry point every caller should use: probe at most once per tree
    state per checkout. This is the whole point of the module — six lens
    agents dispatched in the same wave share ONE answer."""
    root = root or workspace
    if not enabled(authority=settings_authority):
        return {"fingerprint": fingerprint(root), "checks": [],
                "skipped": "TASKPLANE_RUNNABILITY=off",
                "summary": "runnability probe disabled"}
    if not refresh:
        hit = cached(workspace, root)
        if hit is not None:
            hit["cached"] = True
            return hit
    return store(workspace, probe(root, timeout=timeout))


# -------------------------------------------------------------- the notice

def brief_note(result: dict) -> str:
    """What every dispatched agent is told, so none of them re-derives it."""
    if not result or result.get("skipped"):
        return ""
    checks = result.get("checks") or []
    if not checks:
        return ""
    lines = ["\nBUILD/TEST RUNNABILITY (probed ONCE for this review — do NOT "
             "re-probe, and do not spend actions rediscovering it):"]
    for c in checks:
        v = c.get("verdict")
        mark = {RUNS: "CAN RUN", UNAVAILABLE: "CANNOT RUN",
                BROKEN: "CANNOT RUN", UNKNOWN: "UNPROVEN"}.get(v, "UNPROVEN")
        lines.append(f"  {c.get('command')} — {mark}: {c.get('detail', '')}")
    if not can_run_tests(result):
        lines.append(
            "  => Base your verdict on the code and the diff. If a finding "
            "genuinely needs a dynamic check this environment cannot perform, "
            "say so in that finding's `scenario` — do not retry the command.")
    return "\n".join(lines) + "\n"
