"""Design Contract validation (taskplane.design/v1) — extracted from
loop.py in v2.2.1 (review finding: ~470 embedded lines were turning the
state machine into a god module). loop.py delegates here; the public
surface and behavior are unchanged.

Decomposition note (M5): _design_dod_errors below remains the single
entry point; its sections are being split into per-concern helpers as
they change — new validation goes in a helper, not inline.
"""
from __future__ import annotations
from collections.abc import Mapping, Sequence
import contextlib
import hashlib
import hmac
import json
import os
from pathlib import Path, PurePosixPath
import re

import depgraph
import kb
import requirements as reqs
import taskplane_lite as tp
import wiring_closure


def read_json(path: str) -> tuple[dict | None, list]:
    try:
        with open(path, encoding="utf-8") as f:
            value = json.load(f)
    except FileNotFoundError:
        return None, [f"required evidence missing: {path}"]
    except (OSError, ValueError) as exc:
        return None, [f"invalid evidence {path}: {exc}"]
    if not isinstance(value, dict):
        return None, [f"invalid evidence {path}: root must be an object"]
    return value, []


# --------------------------------------------------------------- design

DESIGN_SCHEMA = "taskplane.design/v1"
DESIGN_CONTRACT = os.path.join("design", "contract.json")
DESIGN_NARRATIVE = os.path.join("design", "design.md")

PICKUP_CONTRACT_SCHEMA = "taskplane.approved-pickup-contract/v1"
PICKUP_DESIGN_SCHEMA = "taskplane.pickup-design/v1"
PICKUP_APPROVAL_SCHEMA = "taskplane.pickup-design-approval/v1"
PICKUP_ENGINE_RECEIPT_SCHEMA = "taskplane.pickup-engine-receipt/v1"
_PICKUP_DIGEST = re.compile(r"[0-9a-f]{64}\Z")
_PICKUP_SHA = re.compile(r"[0-9a-f]{40,64}\Z")


class PickupAuthorityError(ValueError):
    """A shelf Design Contract lacks authentic current pickup authority."""


def _pickup_canonical(value: object) -> bytes:
    return json.dumps(
        value, sort_keys=True, separators=(",", ":"), ensure_ascii=True
    ).encode("utf-8")


def _pickup_signed_mapping(value: object, *, fields: frozenset[str],
                           schema: str, label: str, key: bytes,
                           key_id: str) -> dict:
    if not isinstance(value, dict) or set(value) != fields | {"signature"}:
        raise PickupAuthorityError(f"{label} fields are invalid")
    if value.get("schema") != schema or value.get("key_id") != key_id:
        raise PickupAuthorityError(f"{label} identity is invalid")
    unsigned = {name: value[name] for name in fields}
    expected = hmac.new(
        key, _pickup_canonical(unsigned), hashlib.sha256
    ).hexdigest()
    signature = str(value.get("signature") or "")
    if not _PICKUP_DIGEST.fullmatch(signature) or not hmac.compare_digest(
            signature, expected):
        raise PickupAuthorityError(f"{label} signature is invalid")
    return dict(value)


def load_approved_contract_for_pickup(checkout: str, path: str) -> dict:
    """Verify one closed signed shelf authority without reading loop state."""
    try:
        signing_authority = tp._review_contract_authority(  # noqa: SLF001
            checkout, create=False
        )
    except tp.StateError as exc:
        raise PickupAuthorityError("engine receipt key is unavailable") from exc
    key = signing_authority["secret"]
    key_id = signing_authority["key_id"]
    value, errors = read_json(path)
    if errors or value is None:
        raise PickupAuthorityError("; ".join(errors))
    if "engine_receipt" not in value:
        raise PickupAuthorityError("engine receipt is missing")
    if set(value) != {"schema", "design", "approval", "engine_receipt"} or \
            value.get("schema") != PICKUP_CONTRACT_SCHEMA:
        raise PickupAuthorityError("approved Design Contract fields are invalid")
    design = value.get("design")
    if not isinstance(design, dict) or set(design) != {
            "schema", "source_sha", "element"} or \
            design.get("schema") != PICKUP_DESIGN_SCHEMA or \
            not _PICKUP_SHA.fullmatch(str(design.get("source_sha") or "")):
        raise PickupAuthorityError("approved Design Contract body is invalid")
    fingerprint = hashlib.sha256(_pickup_canonical(design)).hexdigest()
    approval = _pickup_signed_mapping(
        value.get("approval"),
        fields=frozenset({"schema", "actor", "design_fingerprint", "key_id"}),
        schema=PICKUP_APPROVAL_SCHEMA, label="approved Design Contract",
        key=key, key_id=key_id,
    )
    if not str(approval.get("actor") or "").startswith("human:") or \
            approval.get("design_fingerprint") != fingerprint:
        raise PickupAuthorityError("approved Design Contract is stale or unsigned")
    receipt = _pickup_signed_mapping(
        value.get("engine_receipt"),
        fields=frozenset({
            "schema", "producer", "source_sha", "design_fingerprint", "key_id",
        }),
        schema=PICKUP_ENGINE_RECEIPT_SCHEMA, label="engine receipt",
        key=key, key_id=key_id,
    )
    if receipt.get("producer") != "taskplane.design-approval-engine/v1" or \
            receipt.get("source_sha") != design["source_sha"] or \
            receipt.get("design_fingerprint") != fingerprint:
        raise PickupAuthorityError("engine receipt is missing or mismatched")
    return {
        "source_sha": design["source_sha"],
        "design_fingerprint": fingerprint,
        "element": design["element"],
        "approval": approval,
        "engine_receipt": receipt,
    }

# ONE contract-id prefix rule (v2.3.0 L1). This is the STRICTER of the two
# rules that used to diverge: plan readiness (depgraph.py) accepts only
# these prefixes on task contract ids, so Design DoD enforces the same rule
# — a design approvable here is always plannable there. depgraph's plan DoR
# should consume this constant when it is next touched.
CONTRACT_ID_PREFIXES = ("contract:", "resource:")

# Boundary nodes the import scanner can never produce (mirrors
# depgraph._is_boundary). Edges touching one of these enter the as-built
# graph only by hand-recording — presence alone is not realization proof.
BOUNDARY_NODE_PREFIXES = ("contract:", "resource:", "svc:", "ext:")


def _text(value) -> bool:
    return bool(str(value or "").strip())


class DesignAcceptanceError(ValueError):
    """The Design acceptance map cannot bind Build to exact test identities."""


R0013_ACCEPTANCE_OUTCOMES = tuple(f"AC{number}" for number in range(1, 8))
ACCEPTANCE_OUTCOME_CEILING = 8
ACCEPTANCE_PAIR_MAP_SCHEMA = "taskplane.acceptance-pair-map/v1"
_ACCEPTANCE_OUTCOME_ID = re.compile(r"^\s*(AC[1-9][0-9]*)\s*:")
_ACCEPTANCE_ARTIFACT_TOKEN = re.compile(r"[a-z0-9]+")

# Closed proof identities copied from the approved R-0013 Design pair map and
# Plan pair table.  Serialization is not inferred from prose vocabulary: each
# approved serial pair must cite these exact dependency identities, and the one
# shared-owner claim must also resolve to the concrete shared Plan owner.
R0013_SERIALIZED_PAIR_PROOFS = {
    ("AC1", "AC4"): {
        "dependencies": ("ac1 authority map", "removed stage edge"),
    },
    ("AC1", "AC7"): {
        "dependencies": ("ac1 native authority receipt",),
    },
    ("AC2", "AC7"): {
        "dependencies": ("design sweep receipt",),
    },
    ("AC3", "AC4"): {
        "dependencies": ("ac3 zero lens execution authorization",),
        "shared_owner": "loop adapter",
    },
    ("AC3", "AC7"): {
        "dependencies": ("execution zero lens receipt",),
    },
    ("AC4", "AC5"): {
        "dependencies": ("ac5 exhaustive plan pair map",),
    },
    ("AC4", "AC6"): {
        "dependencies": ("ac6 non null usage", "budget decision"),
    },
    ("AC4", "AC7"): {
        "dependencies": ("native dispatch", "wait receipts"),
    },
    ("AC5", "AC7"): {
        "dependencies": ("exact seven outcome plan receipt",),
    },
    ("AC6", "AC7"): {
        "dependencies": ("native usage", "bounded handoff receipts"),
    },
}


def _criterion_outcome(value: object) -> str | None:
    match = _ACCEPTANCE_OUTCOME_ID.match(str(value or ""))
    return match.group(1) if match else None


def _normalized_artifact_name(value: object) -> str:
    return " ".join(_ACCEPTANCE_ARTIFACT_TOKEN.findall(str(value).lower()))


def _shared_plan_owner_aliases(task: Mapping) -> set[str]:
    """Names by which a multi-outcome Plan owner can be cited honestly."""
    aliases: set[str] = set()
    task_id = _normalized_artifact_name(task.get("id"))
    task_id = re.sub(r"^t[0-9]+\s+", "", task_id)
    if task_id:
        aliases.add(task_id)
    owner = _normalized_artifact_name(task.get("owner"))
    if owner:
        aliases.add(owner)
    scopes = task.get("scope") or []
    if isinstance(scopes, list):
        for scope in scopes:
            stem = _normalized_artifact_name(
                PurePosixPath(str(scope or "")).stem)
            if not stem:
                continue
            if task.get("type") == "integration":
                aliases.add(f"{stem} adapter")
    return aliases


def acceptance_wave_errors(
    contract: Mapping, tasks: Sequence[Mapping]
) -> list[str]:
    """Validate R-0013's bounded acceptance wave without host authority.

    The approved Design owns the outcome identities, leaf file owners and
    exhaustive pair policy. The Plan owns the concrete leaf task scopes.
    Keeping the check pure lets both the Plan gate and native ready-set
    adapter consume it without introducing scheduling or lifecycle state.
    """
    errors: list[str] = []
    expected = R0013_ACCEPTANCE_OUTCOMES
    expected_set = set(expected)
    expected_pairs = {
        (left, right)
        for index, left in enumerate(expected)
        for right in expected[index + 1:]
    }

    ownership = contract.get("outcome_ownership")
    if not isinstance(ownership, Mapping):
        return ["acceptance wave outcome_ownership must be an object"]

    outcomes = ownership.get("acceptance_outcomes")
    if not isinstance(outcomes, list) or outcomes != list(expected):
        errors.append(
            "acceptance wave must contain exactly AC1 through AC7 in order")
    try:
        maximum = int(ownership.get("maximum_outcomes"))
    except (TypeError, ValueError):
        maximum = -1
    if maximum != ACCEPTANCE_OUTCOME_CEILING:
        errors.append("acceptance wave maximum_outcomes must be exactly 8")
    if isinstance(outcomes, list) and len(outcomes) > ACCEPTANCE_OUTCOME_CEILING:
        errors.append("acceptance wave exceeds the eight-outcome ceiling")

    lanes = ownership.get("leaf_lanes")
    lane_scopes: dict[str, set[str]] = {}
    lane_owners: set[str] = set()
    if not isinstance(lanes, list):
        errors.append("acceptance wave leaf_lanes must be a list")
        lanes = []
    for lane in lanes:
        if not isinstance(lane, Mapping):
            errors.append("every acceptance leaf lane must be an object")
            continue
        outcome = str(lane.get("outcome") or "").strip()
        owner = str(lane.get("owner") or "").strip()
        files = lane.get("exclusive_files")
        if outcome not in expected_set:
            errors.append(f"acceptance leaf lane has unknown outcome: {outcome or '?'}")
            continue
        if outcome in lane_scopes:
            errors.append(f"acceptance outcome has duplicate leaf lanes: {outcome}")
            continue
        if not owner or owner in lane_owners:
            errors.append(
                f"acceptance leaf lane needs one unique named owner: {outcome}")
        else:
            lane_owners.add(owner)
        if (not isinstance(files, list) or not files
                or any(not str(path or "").strip() for path in files)
                or len({str(path) for path in files}) != len(files)):
            errors.append(
                f"acceptance leaf lane needs unique exclusive files: {outcome}")
            lane_scopes[outcome] = set()
        else:
            lane_scopes[outcome] = {str(path) for path in files}
    missing_lanes = sorted(expected_set - set(lane_scopes))
    if missing_lanes:
        errors.append("acceptance wave is missing leaf lanes: "
                      + ", ".join(missing_lanes))

    planned_outcomes: set[str] = set()
    leaf_task_scopes: dict[str, set[str]] = {}
    shared_owner_aliases: dict[tuple[str, str], set[str]] = {
        pair: set() for pair in expected_pairs
    }
    for task in tasks:
        if not isinstance(task, Mapping):
            errors.append("every Plan task must be an object")
            continue
        criterion_ids: list[str] = []
        criteria = task.get("criteria") or []
        if not isinstance(criteria, list):
            errors.append(
                f"Plan task {task.get('id') or '?'} criteria must be a list")
            continue
        for criterion in criteria:
            outcome = _criterion_outcome(criterion)
            if outcome is None:
                errors.append(
                    f"Plan task {task.get('id') or '?'} has a criterion "
                    "without an AC outcome id")
                continue
            criterion_ids.append(outcome)
            planned_outcomes.add(outcome)
            if outcome not in expected_set:
                errors.append(f"Plan contains unknown acceptance outcome: {outcome}")
        unique_ids = set(criterion_ids)
        if len(unique_ids & expected_set) > 1:
            aliases = _shared_plan_owner_aliases(task)
            ordered = [outcome for outcome in expected
                       if outcome in unique_ids]
            for index, left in enumerate(ordered):
                for right in ordered[index + 1:]:
                    shared_owner_aliases[(left, right)].update(aliases)
        if not (task.get("deps") or []) and len(unique_ids) == 1:
            outcome = next(iter(unique_ids))
            scope = task.get("scope") or []
            if outcome in leaf_task_scopes:
                errors.append(
                    f"Plan has duplicate dependency-free leaf tasks for {outcome}")
            elif not isinstance(scope, list) or not scope:
                errors.append(f"Plan leaf task for {outcome} has no owned scope")
            else:
                leaf_task_scopes[outcome] = {str(path) for path in scope}
    if planned_outcomes != expected_set:
        missing = sorted(expected_set - planned_outcomes)
        if missing:
            errors.append("Plan omits acceptance outcomes: " + ", ".join(missing))
        extras = sorted(planned_outcomes - expected_set)
        if extras:
            errors.append("Plan exceeds the approved acceptance outcomes: "
                          + ", ".join(extras))
    missing_leaf_tasks = sorted(expected_set - set(leaf_task_scopes))
    if missing_leaf_tasks:
        errors.append("Plan is missing dependency-free acceptance leaf tasks: "
                      + ", ".join(missing_leaf_tasks))
    for outcome in sorted(expected_set & set(leaf_task_scopes)
                          & set(lane_scopes)):
        if leaf_task_scopes[outcome] != lane_scopes[outcome]:
            errors.append(
                f"Plan leaf scope does not match the exclusive owner for {outcome}")

    pair_map = contract.get("pair_classification")
    if not isinstance(pair_map, Mapping):
        errors.append("acceptance pair classification must be an object")
        return errors
    if pair_map.get("schema") != ACCEPTANCE_PAIR_MAP_SCHEMA:
        errors.append(
            f"acceptance pair map schema must be {ACCEPTANCE_PAIR_MAP_SCHEMA}")
    try:
        declared_count = int(pair_map.get("expected_pair_count"))
    except (TypeError, ValueError):
        declared_count = -1
    if declared_count != len(expected_pairs):
        errors.append("acceptance pair map expected_pair_count must be 21")
    rows = pair_map.get("pairs")
    if not isinstance(rows, list):
        errors.append("acceptance pair map pairs must be a list")
        rows = []
    if len(rows) != len(expected_pairs):
        errors.append("acceptance pair map must contain exactly 21 rows")

    seen: set[tuple[str, str]] = set()
    for row in rows:
        if not isinstance(row, Mapping):
            errors.append("every acceptance pair row must be an object")
            continue
        left = str(row.get("left") or "").strip()
        right = str(row.get("right") or "").strip()
        key = (left, right)
        if key not in expected_pairs:
            errors.append(
                f"acceptance pair row is unknown or out of order: {left}-{right}")
            continue
        if key in seen:
            errors.append(f"acceptance pair row is duplicated: {left}-{right}")
            continue
        seen.add(key)
        disposition = row.get("disposition")
        reason = str(row.get("reason") or "").strip()
        if disposition not in {"parallel", "serialized"}:
            errors.append(
                f"acceptance pair has invalid disposition: {left}-{right}")
            continue
        approved_proof = R0013_SERIALIZED_PAIR_PROOFS.get(key)
        approved_disposition = (
            "serialized" if approved_proof is not None else "parallel"
        )
        if disposition != approved_disposition:
            errors.append(
                "acceptance pair disposition differs from the approved closed "
                f"pair map: {left}-{right}")
            continue
        if not reason:
            errors.append(f"acceptance pair lacks a reason: {left}-{right}")
        if disposition == "serialized":
            if row.get("available_wave") is not None:
                errors.append(
                    f"serialized acceptance pair cannot claim a wave: {left}-{right}")
            normalized_reason = _normalized_artifact_name(reason)
            dependencies = approved_proof.get("dependencies") or ()
            missing_dependencies = [
                dependency for dependency in dependencies
                if dependency not in normalized_reason
            ]
            shared_owner = approved_proof.get("shared_owner")
            valid_shared_owner = not shared_owner or (
                shared_owner in normalized_reason
                and shared_owner in shared_owner_aliases.get(key, set())
            )
            valid_serial_proof = (
                not missing_dependencies and valid_shared_owner
            )
            if reason and not valid_serial_proof:
                errors.append(
                    "serialized acceptance pair lacks a named dependency or "
                    "shared owner proven by approved artifacts: "
                    f"{left}-{right}")
            continue
        wave = str(row.get("available_wave") or "").strip()
        if not wave:
            errors.append(
                f"parallel acceptance pair lacks an available wave: {left}-{right}")
        elif wave != "leaf-wave-1":
            errors.append(
                "every independent acceptance pair must share one available "
                "native wave: exact first native wave leaf-wave-1 required for "
                f"{left}-{right}")
        for source, scopes in (("Design", lane_scopes),
                               ("Plan", leaf_task_scopes)):
            overlap = scopes.get(left, set()) & scopes.get(right, set())
            if overlap:
                errors.append(
                    f"false-disjoint {source} acceptance pair {left}-{right} "
                    "overlaps: " + ", ".join(sorted(overlap)))
    missing_pairs = sorted(expected_pairs - seen)
    if missing_pairs:
        errors.append("acceptance pair map is missing: " + ", ".join(
            f"{left}-{right}" for left, right in missing_pairs))
    return errors


def acceptance_test_map(contract: Mapping) -> dict[str, list[str]] | None:
    """Preserve the public Design API over the pure selector owner."""
    try:
        return wiring_closure.acceptance_test_map(contract)
    except wiring_closure.WiringClosureError as exc:
        raise DesignAcceptanceError(str(exc)) from exc


def checkpoint_acceptance_tests(
    ws: str, contract: Mapping, ac_ids: Sequence[str]
) -> dict | None:
    """Preserve the public Design API over the pure selector owner."""
    try:
        return wiring_closure.checkpoint_acceptance_tests(ws, contract, ac_ids)
    except wiring_closure.WiringClosureError as exc:
        raise DesignAcceptanceError(str(exc)) from exc


def edge_key(row) -> str:
    """Canonical proposed-edge identity (L8, v2.2.1) — one format string."""
    row = row if isinstance(row, dict) else {}
    return f"{row.get('from')}->{row.get('to')}:{row.get('kind')}"


def design_path(ws: str, rel: str) -> str:
    return os.path.join(ws, rel)


def design_contract(ws: str) -> tuple[dict | None, list]:
    return read_json(design_path(ws, DESIGN_CONTRACT))


def design_safe_rel(rel) -> str | None:
    rel = str(rel or "").replace("\\", "/").strip()
    if (not rel or os.path.isabs(rel) or rel == ".."
            or rel.startswith("../") or "/../" in rel
            or not rel.startswith("design/")):
        return None
    return rel


def design_evidence_paths(ws: str, contract: dict | None = None) -> list:
    paths = [DESIGN_CONTRACT, DESIGN_NARRATIVE]
    contract = contract or (design_contract(ws)[0] or {})
    visual = contract.get("visualization") or {}
    if visual.get("required"):
        rel = design_safe_rel(visual.get("path"))
        if rel:
            paths.append(rel)
    return paths


def _primary_workspace(ws: str) -> str | None:
    """The orchestrator workspace a wave agent worktree belongs to, or None.

    The requirement store is a LOOP-level resource keyed by workspace path.
    A parallel wave evaluates task DoD inside linked worktrees, whose paths
    historically keyed a DIFFERENT (empty) store — so requirement_fingerprint
    read \0MISSING\0 there and the design approval looked tampered-with in
    every agent worktree (found live by the v3 Phase-1 dogfood loop).

    Managed workers carry their primary checkout in the secure Git locator.
    Legacy workers use `<primary>/.tp-work/<task>` rather than git common-dir,
    which can over-resolve nested linked worktrees. Failure remains closed."""
    with contextlib.suppress(Exception):
        import storage as runtime_storage
        locator = runtime_storage.load_workspace_locator(ws)
        primary = os.path.realpath(str((locator or {}).get(
            "primary_checkout") or ""))
        if locator and primary != os.path.realpath(ws) and os.path.isdir(primary):
            return primary
    marker = os.sep + ".tp-work" + os.sep
    p = os.path.abspath(ws)
    idx = p.find(marker)
    if idx <= 0:
        return None
    primary = p[:idx]
    return primary if os.path.isdir(primary) else None


def requirement_fingerprint(ws: str, rid) -> str:
    """Content hash of the anchored requirement record (v2.3.0 M2):
    the index entry AND the KB markdown record. Any edit to either after
    design approval changes this hash and so invalidates the approval —
    requirement→design traceability is pinned, not assumed.

    v3 dogfood fix: in a linked worktree (parallel wave agent workspace) the
    workspace-keyed store is empty — resolve the record from the PRIMARY
    workspace's store instead, so task DoD inside `.tp-work/<task>` sees the
    same requirement the approval pinned. Fail-closed is preserved: a truly
    missing/edited record still changes the hash."""
    h = hashlib.sha256()
    rid = str(rid or "").strip()
    rec = reqs.get_requirement(ws, rid) if rid else None
    if rec is None and rid:
        primary = _primary_workspace(ws)
        if primary:
            ws = primary
            rec = reqs.get_requirement(ws, rid)
    if rec is None:
        h.update(b"\0MISSING\0")
        return h.hexdigest()
    h.update(json.dumps(rec, sort_keys=True, separators=(",", ":"),
                        default=str).encode("utf-8",
                                            errors="surrogateescape"))
    rel = str(rec.get("file") or "").strip()
    if rel:
        h.update(b"\0record\0")
        try:
            with open(os.path.join(reqs.kb_dir(ws), rel), "rb") as f:
                h.update(f.read())
        except OSError:
            h.update(b"\0MISSING\0")
    return h.hexdigest()


def design_evidence_fingerprint(ws: str,
                                 contract: dict | None = None) -> str:
    """Fingerprint exactly the approved design evidence, not source code.

    v2.3.0 M2: the anchored requirement record is pinned too — a
    requirement edit after approval invalidates the design approval."""
    contract = contract if contract is not None \
        else (design_contract(ws)[0] or {})
    h = hashlib.sha256()
    for rel in sorted(set(design_evidence_paths(ws, contract))):
        h.update(b"\0path\0")
        h.update(rel.encode("utf-8", errors="surrogateescape"))
        try:
            with open(design_path(ws, rel), "rb") as f:
                h.update(f.read())
        except OSError:
            h.update(b"\0MISSING\0")
    rid = str(contract.get("requirement") or "").strip()
    h.update(b"\0requirement\0")
    h.update(rid.encode("utf-8", errors="surrogateescape"))
    h.update(requirement_fingerprint(ws, rid).encode("ascii"))
    return h.hexdigest()


def design_content_fingerprint(ws: str,
                                contract: dict | None = None) -> str:
    """Fingerprint of the design CONTENT a lens run judged: the contract
    body WITHOUT its own lens_evidence (so evidence can bind to the content
    without self-reference), the narrative, and any required visualization.
    A lens-evidence row must carry this value as content_fingerprint —
    change the design and the old attestation mechanically goes stale."""
    contract = contract if contract is not None \
        else (design_contract(ws)[0] or {})
    h = hashlib.sha256()
    body = {k: contract[k] for k in sorted(contract)
            if k != "lens_evidence"}
    h.update(b"\0contract-body\0")
    h.update(json.dumps(body, sort_keys=True, separators=(",", ":"),
                        default=str).encode("utf-8",
                                            errors="surrogateescape"))
    for rel in sorted(set(design_evidence_paths(ws, contract))
                      - {DESIGN_CONTRACT}):
        h.update(b"\0path\0")
        h.update(rel.encode("utf-8", errors="surrogateescape"))
        try:
            with open(design_path(ws, rel), "rb") as f:
                h.update(f.read())
        except OSError:
            h.update(b"\0MISSING\0")
    return h.hexdigest()


def design_current_errors(ws: str, state: dict) -> list:
    """Validate the approved design anchor without freezing design evidence.

    Design artifacts are living model output and may be refined as the model,
    available evidence, or host capabilities evolve.  Approval therefore no
    longer turns their byte fingerprint into a repository-wide execution
    lock.  The requirement identity remains immutable: changing which
    requirement the design belongs to still requires a new loop.
    """
    if not state.get("design_required") or not state.get("design_fingerprint"):
        return []
    contract, errors = design_contract(ws)
    if errors:
        return ["approved design is unavailable: " + e for e in errors]
    approved_requirement = str(state.get("requirement_id") or "").strip()
    current_requirement = str((contract or {}).get("requirement") or "").strip()
    if approved_requirement and current_requirement != approved_requirement:
        return ["approved design is anchored to a different requirement — "
                "start a new loop to re-anchor it"]
    return []


def design_attach_requirement(ws: str, state: dict, rid) -> list:
    """Mechanical exit for a design loop started without --req (v2.3.0 H1).

    The documented journey (`loop init --design` without --req, author the
    spec, pass the pm gate) used to dead-end at the design DoR with no
    sanctioned way to attach an R-id mid-loop. This attaches one WITHOUT
    weakening the gate: it validates exactly what the design DoR itself
    demands (the requirement exists, has acceptance criteria, and carries
    no open questions) and refuses to swap an already-anchored requirement.
    Mutates state["requirement_id"] on success; the caller persists state
    and re-runs the DoR — nothing here bypasses any check downstream.
    Returns a list of errors; empty means attached (or already attached)."""
    rid = str(rid or "").strip()
    if not rid:
        return ["a requirement R-id is required to anchor the design"]
    existing = str(state.get("requirement_id") or "").strip()
    if existing and existing != rid:
        return [f"loop is already anchored to {existing} — refusing to swap "
                "requirements mid-loop; start a new loop to re-anchor"]
    rec = reqs.get_requirement(ws, rid)
    if rec is None:
        return [f"requirement {rid} does not exist — record it first with "
                "`tp req new \"<title>\" --acceptance ...`"]
    if not rec.get("acceptance"):
        return [f"requirement {rid} has no acceptance criteria — the design "
                "DoR requires testable acceptance before the HOW is proposed"]
    if rec.get("open_questions"):
        return [f"requirement {rid} has unresolved open questions: "
                + "; ".join(str(q) for q in rec["open_questions"])]
    if existing != rid:
        state["requirement_id"] = rid
        tp.trace(ws, "design_requirement_attached", id=rid)
    return []


def design_dor(ws: str, state: dict) -> dict:
    """Entry gate for the proposed-HOW phase."""
    blockers, warnings = [], []
    rid = state.get("requirement_id")
    rec = reqs.get_requirement(ws, rid) if rid else None
    if not rid:
        blockers.append(
            "Design must be anchored to a requirement R-id — record one "
            "with `tp req new \"<title>\" --acceptance ...`, then attach it "
            "to this loop with `loop gate pass --req R-xxxx` (or `loop next "
            "--req R-xxxx`); the in-flight loop is preserved")
    elif rec is None:
        blockers.append(f"Design requirement {rid} does not exist")
    else:
        if not rec.get("acceptance"):
            blockers.append("Design requirement has no acceptance criteria")
        if rec.get("open_questions"):
            blockers.append("Design requirement has unresolved questions: "
                            + "; ".join(rec["open_questions"]))
    graph = depgraph.load(ws)
    meta = graph.get("meta") or {}
    if not meta.get("content_fingerprint"):
        blockers.append("baseline dependency graph is missing — run graph scan")
    elif meta.get("scanned_head") and meta.get("scanned_head") != tp.git_head(ws):
        blockers.append("baseline dependency graph is stale for the current "
                        "HEAD — run graph scan to refresh it")
    if not graph.get("modules"):
        warnings.append("baseline graph has no source modules; treat this as "
                        "greenfield and declare every proposed module")
    if not kb.current_state(ws):
        warnings.append("current-state inventory is empty; ground the design "
                        "in cited repository sources and the baseline graph")
    return {"ready": not blockers, "blockers": blockers,
            "warnings": warnings}


def design_dod_errors(ws: str, state: dict) -> list:
    """Mechanical Design Contract completion and graph-isolation proof."""
    contract, errors = design_contract(ws)
    if errors:
        return errors
    assert contract is not None

    def text(value) -> bool:
        return bool(str(value or "").strip())

    def object_field(name: str) -> dict:
        value = contract.get(name)
        if not isinstance(value, dict):
            errors.append(f"design {name} must be an object")
            return {}
        return value

    def text_list(value) -> bool:
        return (isinstance(value, list) and bool(value)
                and all(text(item) for item in value))

    if contract.get("schema") != DESIGN_SCHEMA:
        errors.append(f"design schema must be {DESIGN_SCHEMA}")
    if contract.get("requirement") != state.get("requirement_id"):
        errors.append("design requirement does not match the loop requirement")
    for field in ("title", "summary", "decision"):
        if not text(contract.get(field)):
            errors.append(f"design {field} is missing")

    current = object_field("current_state")
    if not text(current.get("summary")) or not text_list(current.get("sources")):
        errors.append("design current_state needs a summary and cited sources")

    alternatives = contract.get("alternatives") or []
    if not isinstance(alternatives, list) or len(alternatives) < 2:
        errors.append("design must compare at least two approaches")
        alternatives = []
    alt_ids = set()
    for alt in alternatives:
        if not isinstance(alt, dict):
            errors.append("every design alternative must be an object")
            continue
        aid = str(alt.get("id") or "").strip()
        if not aid or aid in alt_ids:
            errors.append("design alternatives need unique non-empty ids")
        alt_ids.add(aid)
        trade = alt.get("tradeoffs")
        if not isinstance(trade, dict):
            trade = {}
        if (not text(alt.get("name")) or not text(alt.get("description"))
                or not text_list(trade.get("gains"))
                or not text_list(trade.get("costs"))
                or not text(trade.get("revisit_when"))):
            errors.append(f"alternative {aid or '?'} needs description, "
                          "gains, costs, and revisit_when")
    if contract.get("selected_approach") not in alt_ids:
        errors.append("selected_approach does not name a declared alternative")

    modules = object_field("modules")
    declared_modules = {str(x).strip() for x in
                        list(modules.get("existing") or [])
                        + list(modules.get("new") or []) if str(x).strip()}
    if not declared_modules:
        errors.append("design modules must name existing or new modules")

    contracts = contract.get("contracts") or []
    if not isinstance(contracts, list):
        errors.append("design contracts must be a list")
        contracts = []
    contract_ids = set()
    for row in contracts:
        if not isinstance(row, dict) or not text(row.get("id")) \
                or not text(row.get("relation")) \
                or not text(row.get("description")):
            errors.append("every design contract needs relation, id, and description")
            continue
        if row.get("relation") not in ("provides", "consumes", "changes"):
            errors.append("design contract relation must be provides, consumes, or changes")
        cid = str(row["id"])
        # v2.3.0 L1: one rule with plan readiness — an id the plan DoR would
        # reject must never survive Design approval (dead-end otherwise).
        if not cid.strip().startswith(CONTRACT_ID_PREFIXES):
            errors.append("design contract ids need contract: or resource: "
                          "prefixes (the plan readiness rule): " + cid)
        contract_ids.add(cid)
    rec = reqs.get_requirement(ws, state.get("requirement_id"))
    required_contracts = {
        str(row.get("id") if isinstance(row, dict) else row)
        for row in ((rec or {}).get("contracts") or [])
        if str(row.get("id") if isinstance(row, dict) else row).strip()
    }
    missing_contracts = sorted(required_contracts - contract_ids)
    if missing_contracts:
        errors.append("design omits requirement contracts: "
                      + ", ".join(missing_contracts))

    graph = object_field("graph")
    current_fp = (depgraph.load(ws).get("meta") or {}).get(
        "content_fingerprint")
    baseline_fp = state.get("design_graph_fingerprint")
    if not baseline_fp:
        errors.append("design graph baseline was not captured by the "
                      "engine — run `loop next` once at the design step to "
                      "capture it, then gate again")
    if current_fp != baseline_fp:
        errors.append("as-built graph changed during Design; proposed edges "
                      "must remain an overlay")
    if graph.get("baseline_fingerprint") != baseline_fp:
        errors.append("design graph does not cite the captured baseline fingerprint")
    proposed_modules = {str(x).strip() for x in
                        (graph.get("proposed_modules") or []) if str(x).strip()}
    if not proposed_modules:
        errors.append("design graph has no proposed_modules")
    if not declared_modules <= proposed_modules:
        errors.append("design graph does not include every declared module")
    edges = graph.get("proposed_edges")
    if not isinstance(edges, list):
        errors.append("design graph proposed_edges must be a list")
        edges = []
    known = set((depgraph.load(ws).get("modules") or {})) | proposed_modules
    edge_nodes = set()
    for edge in edges:
        if not isinstance(edge, dict):
            errors.append("every proposed graph edge must be an object")
            continue
        for end in ("from", "to"):
            node = str(edge.get(end) or "").strip()
            if not node:
                errors.append(f"proposed graph edge is missing {end}")
            elif node not in known and not node.startswith(
                    ("contract:", "resource:", "svc:", "ext:")):
                errors.append(f"proposed graph edge has undeclared node: {node}")
            else:
                edge_nodes.add(node)
        if not text(edge.get("kind")) or not text(edge.get("reason")):
            errors.append("proposed graph edges need kind and reason")
    if contract_ids - edge_nodes:
        errors.append("design contracts are missing from the proposed graph: "
                      + ", ".join(sorted(contract_ids - edge_nodes)))
    policy = graph.get("depth_policy")
    if not isinstance(policy, dict):
        errors.append("design graph depth_policy must be an object")
        policy = {}
    try:
        local_depth = int(policy.get("local_depth"))
        contract_depth = int(policy.get("contract_depth"))
        requirement_depth = int(policy.get("requirement_depth"))
    except (TypeError, ValueError):
        local_depth = contract_depth = requirement_depth = -1
    if not 1 <= local_depth <= 10:
        errors.append("design graph local_depth must be between 1 and 10")
    if policy.get("boundary_mode") not in ("stop", "contract-only", "expand"):
        errors.append("design graph boundary_mode is invalid")
    if contract_depth < 0 or requirement_depth < 0:
        errors.append("design graph contract/requirement depth must be non-negative")
    if policy.get("boundary_mode") == "contract-only" and contract_depth > 1:
        errors.append("contract-only design may traverse only one contract level")
    for field in ("dor", "dod"):
        rows = graph.get(field)
        if not isinstance(rows, list) or not rows:
            errors.append(f"design graph {field} checks are missing")
            continue
        for row in rows:
            if not isinstance(row, dict) or not text(row.get("check")) \
                    or not text(row.get("evidence")):
                errors.append(f"every graph {field} check needs check and evidence")

    criteria = list((rec or {}).get("acceptance") or [])
    mapping = contract.get("acceptance_map") or []
    if not isinstance(mapping, list):
        errors.append("design acceptance_map must be a list")
        mapping = []
    mapped = [row.get("criterion") for row in mapping
              if isinstance(row, dict)]
    for criterion in criteria:
        rows = [row for row in mapping if isinstance(row, dict)
                and row.get("criterion") == criterion]
        if len(rows) != 1 or not text(rows[0].get("design_element")) \
                or not text(rows[0].get("validation")):
            errors.append("acceptance criterion lacks one complete design mapping: "
                          + criterion)
    extras = sorted({str(x) for x in mapped if x not in criteria})
    if extras:
        errors.append("design maps unknown acceptance criteria: "
                      + ", ".join(extras))
    try:
        acceptance_test_map(contract)
    except DesignAcceptanceError as exc:
        errors.append("design acceptance tests are invalid: " + str(exc))

    for field, required in (("risks", ("risk", "mitigation", "owner")),
                            ("failure_modes", ("mode", "detection", "recovery"))):
        rows = contract.get(field)
        if not isinstance(rows, list) or not rows:
            errors.append(f"design {field} evidence is missing")
            continue
        for row in rows:
            if not isinstance(row, dict) or any(not text(row.get(k))
                                                for k in required):
                errors.append(f"every {field} row needs " + ", ".join(required))
    observability = object_field("observability")
    if not text_list(observability.get("signals")):
        errors.append("design observability signals are missing")
    # v2.3.0 L2: an actionable alert and a rationale-for-none are distinct,
    # reviewable shapes — exactly one of the two fields must be present.
    has_alerts = "alerts" in observability
    has_none_rationale = "alerts_none_rationale" in observability
    if has_alerts == has_none_rationale:
        errors.append("design observability needs exactly one of "
                      "alerts: [...] (actionable alerts) or "
                      "alerts_none_rationale: \"...\" (why none are needed)")
    elif has_alerts and not text_list(observability.get("alerts")):
        errors.append("design observability alerts must be a non-empty list "
                      "of actionable alert descriptions")
    elif has_none_rationale \
            and not text(observability.get("alerts_none_rationale")):
        errors.append("design observability alerts_none_rationale must "
                      "explain why no alerts are needed")
    rollout = object_field("rollout")
    if not text(rollout.get("strategy")) or not text(rollout.get("rollback")):
        errors.append("design rollout needs strategy and rollback")

    visual = object_field("visualization")
    if not isinstance(visual.get("required"), bool):
        errors.append("design visualization.required must be boolean")
    elif visual.get("required"):
        rel = design_safe_rel(visual.get("path"))
        if visual.get("kind") not in (
                "dependency-graph", "sequence", "state-transition",
                "data-flow", "ui-flow") or not rel:
            errors.append("required design visualization needs kind and safe design/ path")
        elif not os.path.isfile(design_path(ws, rel)) \
                or os.path.getsize(design_path(ws, rel)) == 0:
            errors.append("required design visualization is missing or empty")
    elif not text(visual.get("reason")):
        errors.append("skipped design visualization needs a reason")

    lens_evidence = contract.get("lens_evidence") or []
    if not isinstance(lens_evidence, list):
        errors.append("design lens_evidence must be a list")
        lens_evidence = []
    evidence = [row for row in lens_evidence
                if isinstance(row, dict)
                and row.get("lens") == "solution-design"]
    try:
        solution_blockers = int(evidence[0].get("blockers") or 0) \
            if len(evidence) == 1 else -1
    except (TypeError, ValueError):
        solution_blockers = -1
    if (len(evidence) != 1 or evidence[0].get("verdict") != "pass"
            or solution_blockers != 0
            or not text(evidence[0].get("evidence"))):
        errors.append("solution-design lens must pass with evidence and no blockers")
    else:
        # v2.3.0 M3: the row must be BOUND to the content it judged and to
        # WHO judged it — a bare designer-typed pass row is no longer enough.
        row = evidence[0]
        if not text(row.get("produced_by")):
            errors.append("solution-design lens evidence must record "
                          "produced_by — WHO ran the lens")
        expected_fp = design_content_fingerprint(ws, contract)
        if row.get("content_fingerprint") != expected_fp:
            errors.append("solution-design lens evidence is not bound to the "
                          "current design content — re-run the lens against "
                          "this design and record its content_fingerprint "
                          f"(design_content_fingerprint, now {expected_fp})")
        independent = row.get("independent") is True
        self_attested = row.get("self_attested") is True
        if independent == self_attested:
            errors.append("solution-design lens evidence must declare exactly "
                          "one of independent: true or self_attested: true — "
                          "implicit self-attestation is never accepted "
                          "silently; self_attested rows are surfaced to the "
                          "human at the approval gate")
    if not isinstance(contract.get("open_questions"), list):
        errors.append("design open_questions is required — list unresolved "
                      "questions, or [] when none")
    elif contract.get("open_questions"):
        errors.append("design has unresolved open_questions")
    try:
        with open(design_path(ws, DESIGN_NARRATIVE), encoding="utf-8") as f:
            if not f.read().strip():
                errors.append("design narrative is empty")
    except OSError:
        errors.append("design narrative is missing: " + DESIGN_NARRATIVE)
    return errors


def design_approval_notices(ws: str, contract: dict | None = None) -> list:
    """Human-visible notices the design approval gate must render (v2.3.0
    M3). These never unblock anything — but a self-attested lens row is
    surfaced HERE, at the human gate, instead of being silently accepted."""
    contract = contract if contract is not None \
        else (design_contract(ws)[0] or {})
    notices = []
    rows = contract.get("lens_evidence")
    for row in rows if isinstance(rows, list) else []:
        if isinstance(row, dict) and row.get("self_attested") is True:
            who = str(row.get("produced_by") or "").strip() or "unknown"
            notices.append(
                f"{str(row.get('lens') or 'lens').strip()} evidence is "
                f"SELF-ATTESTED by {who} — no independent lens run backs "
                "it; verify the lens checks yourself before approving")
    return notices


def _plan_stabilization_errors(state: Mapping, tasks: list) -> list[str]:
    """Require one bounded successor after two governed Plan returns.

    The initial Plan plus two append-only replan-history rows is the third
    Plan presentation.  Reuse that existing history as authority rather than
    adding a second counter or changing the approved Plan artifact.
    """
    history = state.get("replan_history")
    if not isinstance(history, list) or len(history) < 2:
        return []
    candidates = [
        task for task in tasks
        if isinstance(task, Mapping)
        and str(task.get("type") or "").strip() == "stabilization"
    ]
    if len(candidates) != 1:
        return ["third Plan return requires exactly one pending successor "
                "task with type=stabilization"]
    candidate = candidates[0]
    candidate_id = str(candidate.get("id") or "").strip()
    id_owners = [
        task for task in tasks
        if isinstance(task, Mapping)
        and str(task.get("id") or "").strip() == candidate_id
    ]
    if not candidate_id or len(id_owners) != 1:
        return ["third Plan return has an ambiguous stabilization successor; "
                "exactly one uniquely named pending task is required"]
    if candidate.get("status", "pending") != "pending":
        return ["third Plan return requires the stabilization successor to "
                "be pending"]
    return []


def _task_acceptance_reference_errors(
        task: Mapping, declared_tests: Mapping | None) -> list[str]:
    """Validate optional requirement/Design ownership separately from DoD.

    ``criteria`` is the task-local incremental completion contract.  Exact
    top-level acceptance ownership belongs in ``acceptance_refs``; when that
    field is absent, criteria equal to Design keys retain their legacy
    ownership meaning through ``requirement_coverage_errors``.
    """
    if declared_tests is None or "acceptance_refs" not in task:
        return []
    refs = task.get("acceptance_refs")
    if not isinstance(refs, list):
        return [f"plan task {task.get('id') or '?'} acceptance_refs is "
                "malformed: expected a list of exact Design acceptance "
                "criteria"]
    if any(not isinstance(ref, str) or not ref.strip()
           or ref != ref.strip() for ref in refs) or \
            len(set(refs)) != len(refs):
        return [f"plan task {task.get('id') or '?'} acceptance_refs is "
                "malformed: values must be unique nonempty exact strings"]
    unknown = sorted(set(refs) - set(declared_tests))
    if unknown:
        return [f"plan task {task.get('id') or '?'} acceptance_refs are not "
                "Design-declared: " + "; ".join(unknown)]
    return []


def design_plan_errors(ws: str, state: dict) -> list:
    """Approved Design Contract → implementation plan conformance."""
    errors = design_current_errors(ws, state)
    if errors or not state.get("design_required"):
        return errors
    contract, read_errors = design_contract(ws)
    if read_errors:
        return read_errors
    assert contract is not None
    try:
        declared_tests = acceptance_test_map(contract)
    except DesignAcceptanceError as exc:
        return ["design acceptance tests are invalid: " + str(exc)]
    tasks = state.get("tasks") or []
    errors.extend(_plan_stabilization_errors(state, tasks))
    if contract.get("requirement") == "R-0013":
        errors.extend(acceptance_wave_errors(contract, tasks))
    planned_modules = set()
    planned_contracts = set()
    planned_edges = set()
    for task in tasks:
        planned_modules.update(
            depgraph.scope_modules(ws, task.get("scope") or []))
        planned_modules.update(str(x) for x in (task.get("new_modules") or []))
        for row in task.get("contracts") or []:
            cid = row.get("id") if isinstance(row, dict) else row
            if str(cid or "").strip():
                planned_contracts.add(str(cid))
        for row in task.get("design_edges") or []:
            if isinstance(row, dict):
                planned_edges.add(
                    edge_key(row))
            elif str(row or "").strip():
                planned_edges.add(str(row))
        errors.extend(_task_acceptance_reference_errors(
            task, declared_tests))
    graph = contract.get("graph") or {}
    expected_modules = {str(x) for x in graph.get("proposed_modules") or []}
    missing_modules = sorted(expected_modules - planned_modules)
    if missing_modules:
        errors.append("approved design modules are not covered by the plan: "
                      + ", ".join(missing_modules))
    expected_contracts = {
        str(row.get("id") if isinstance(row, dict) else row)
        for row in contract.get("contracts") or []
    }
    missing_contracts = sorted(expected_contracts - planned_contracts)
    if missing_contracts:
        errors.append("approved design contracts are not covered by the plan: "
                      + ", ".join(missing_contracts))
    expected_edges = {
        edge_key(row)
        for row in graph.get("proposed_edges") or [] if isinstance(row, dict)
    }
    missing_edges = sorted(expected_edges - planned_edges)
    if missing_edges:
        errors.append("approved design edges are not covered by the plan: "
                      + ", ".join(missing_edges))
    planned_policy = depgraph.aggregate_impact_policy(tasks)
    expected_policy = graph.get("depth_policy") or {}
    ranks = {"stop": 0, "contract-only": 1, "expand": 2}
    if (planned_policy.get("local_depth", 0)
            < int(expected_policy.get("local_depth", 0) or 0)
            or planned_policy.get("contract_depth", 0)
            < int(expected_policy.get("contract_depth", 0) or 0)
            or planned_policy.get("requirement_depth", 0)
            < int(expected_policy.get("requirement_depth", 0) or 0)
            or ranks.get(planned_policy.get("boundary_mode"), 1)
            < ranks.get(expected_policy.get("boundary_mode"), 1)):
        errors.append("plan dependency depth policy is narrower than the "
                      "approved design depth policy")
    return errors


def design_review_errors(ws: str, state: dict, meta: dict) -> list:
    """Approved design → final as-built review evidence."""
    errors = design_current_errors(ws, state)
    if errors or not state.get("design_required") or state.get("design_only"):
        return errors
    evidence = meta.get("design")
    if not isinstance(evidence, dict):
        return ["engineering review is missing approved-design conformance evidence"]
    if evidence.get("fingerprint") != state.get("design_fingerprint"):
        errors.append("engineering review uses the wrong design fingerprint")
    if evidence.get("verdict") != "conformant":
        errors.append("engineering review reports design drift; return to Design "
                      "and re-plan before sign-off")
    for field in ("modules_checked", "edges_checked", "contracts_checked",
                  "drift"):
        if not isinstance(evidence.get(field), list):
            errors.append(f"engineering design evidence {field} must be a list")
    contract, _ = design_contract(ws)
    graph = (contract or {}).get("graph") or {}
    expected_modules = {str(x) for x in graph.get("proposed_modules") or []}
    as_built = depgraph.load(ws)
    actual_modules = set(as_built.get("modules") or {})
    unrealized_modules = expected_modules - actual_modules
    if unrealized_modules:
        errors.append("as-built graph is missing designed modules: "
                      + ", ".join(sorted(unrealized_modules)))
    checked_modules = {str(x) for x in evidence.get("modules_checked") or []} \
        if isinstance(evidence.get("modules_checked"), list) else set()
    if expected_modules - checked_modules:
        errors.append("engineering review did not check every designed module: "
                      + ", ".join(sorted(expected_modules - checked_modules)))
    expected_edges = {
        edge_key(row)
        for row in graph.get("proposed_edges") or [] if isinstance(row, dict)
    }
    actual_edges = {
        edge_key(row)
        for row in as_built.get("edges") or [] if isinstance(row, dict)
    }
    unrealized_edges = expected_edges - actual_edges
    if unrealized_edges:
        errors.append("as-built graph is missing designed edges: "
                      + ", ".join(sorted(unrealized_edges)))
    checked_edges = {str(x) for x in evidence.get("edges_checked") or []} \
        if isinstance(evidence.get("edges_checked"), list) else set()
    if expected_edges - checked_edges:
        errors.append("engineering review did not check every designed edge: "
                      + ", ".join(sorted(expected_edges - checked_edges)))
    # v2.3.0 M4: an edge the import scanner can never see (a boundary
    # endpoint) enters the as-built graph only by hand-recording, so its
    # presence proves the edge was typed in — not that the code realizes
    # it. Each such edge needs an explicit human-visible declaration with
    # concrete evidence, surfaced at the EM gate.
    unscannable = {
        edge_key(row) for row in graph.get("proposed_edges") or []
        if isinstance(row, dict)
        and (str(row.get("from") or "").startswith(BOUNDARY_NODE_PREFIXES)
             or str(row.get("to") or "").startswith(BOUNDARY_NODE_PREFIXES))}
    edge_rows = evidence.get("edge_evidence")
    if edge_rows is not None and not isinstance(edge_rows, list):
        errors.append("engineering design evidence edge_evidence must be a list")
        edge_rows = []
    declared = {str(row.get("edge") or "").strip(): row
                for row in edge_rows or [] if isinstance(row, dict)}
    for key in sorted(unscannable):
        row = declared.get(key)
        if not isinstance(row, dict) or not _text(row.get("evidence")) \
                or not _text(row.get("declared_by")):
            errors.append(
                "scanner-invisible designed edge needs an explicit "
                "realization declaration in edge_evidence — edge, evidence "
                "(file:line, test, or probe) and declared_by: " + key)
    expected_contracts = {
        str(row.get("id") if isinstance(row, dict) else row)
        for row in (contract or {}).get("contracts") or []
    }
    unrealized_contracts = expected_contracts - actual_modules
    if unrealized_contracts:
        errors.append("as-built graph is missing designed contracts: "
                      + ", ".join(sorted(unrealized_contracts)))
    checked_contracts = {str(x) for x in evidence.get("contracts_checked") or []} \
        if isinstance(evidence.get("contracts_checked"), list) else set()
    if expected_contracts - checked_contracts:
        errors.append("engineering review did not check every designed contract: "
                      + ", ".join(sorted(expected_contracts - checked_contracts)))
    # v2.3.0 L3: the real rule is ANY drift entry blocks — say so, and give
    # explained/accepted deviations a representation the EM gate renders
    # instead of incentivizing under-reporting.
    if isinstance(evidence.get("drift"), list) and evidence.get("drift"):
        errors.append(
            "engineering review records design drift — any drift entry "
            "blocks sign-off; return through Design, or move a "
            "human-accepted deviation to accepted_drift with drift, "
            "reason, and accepted_by")
    accepted = evidence.get("accepted_drift")
    if accepted is not None:
        if not isinstance(accepted, list):
            errors.append("engineering design evidence accepted_drift "
                          "must be a list")
        else:
            for row in accepted:
                if not isinstance(row, dict) or any(
                        not _text(row.get(k))
                        for k in ("drift", "reason", "accepted_by")):
                    errors.append("every accepted_drift entry needs drift, "
                                  "reason, and accepted_by")
    return errors


def design_review_notices(meta: dict) -> list:
    """Render lines for the EM/sign-off gate (v2.3.0 L3 + M4): accepted
    design drift and hand-declared edge realizations are VISIBLE on a
    passing review instead of dead-on-pass."""
    evidence = (meta or {}).get("design")
    if not isinstance(evidence, dict):
        return []
    notices = []
    accepted = evidence.get("accepted_drift")
    for row in accepted if isinstance(accepted, list) else []:
        if isinstance(row, dict):
            who = str(row.get("accepted_by") or "").strip() or "unknown"
            notices.append(
                f"accepted design drift (by {who}): "
                f"{str(row.get('drift') or '').strip()} — "
                f"{str(row.get('reason') or '').strip()}")
    edge_rows = evidence.get("edge_evidence")
    for row in edge_rows if isinstance(edge_rows, list) else []:
        if isinstance(row, dict):
            who = str(row.get("declared_by") or "").strip() or "unknown"
            notices.append(
                "declared realization of scanner-invisible edge "
                f"{str(row.get('edge') or '').strip()}: "
                f"{str(row.get('evidence') or '').strip()} "
                f"(declared by {who})")
    return notices
