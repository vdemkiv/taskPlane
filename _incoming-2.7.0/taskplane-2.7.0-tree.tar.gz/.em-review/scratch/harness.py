#!/usr/bin/env python3
"""Empirical render harness for the tp-lens review of taskplane/dashboard.py.

Builds fixture workspaces (loop mid-execute, malformed trace, exhausted
budget, empty store, XSS-injected state) and renders EVERY surface, measuring
UTF-8 bytes vs PAGE_BUDGET and writing artifacts to scratch/ for inspection.
Writes ONLY under .em-review/scratch and /tmp/tp-fixture-*.
"""
import json, os, sys, time, shutil, random, io

SCRATCH = "/tmp/fix23/.em-review/scratch"
sys.path.insert(0, "/tmp/fix23/taskplane")
os.environ["TASKPLANE_HOME"] = "/tmp/tp-fixture-store"
shutil.rmtree("/tmp/tp-fixture-store", ignore_errors=True)

import taskplane_lite as tp
import loop as _loop
import dashboard as dash

BUDGET = dash.PAGE_BUDGET
NOW = time.time()
report = {}


def bmeasure(name, html):
    b = len(html.encode("utf-8"))
    report[name] = {"bytes": b, "over_budget": b > BUDGET}
    return b


def save(name, html):
    with open(os.path.join(SCRATCH, name), "w", encoding="utf-8") as f:
        f.write(html)


# ---------------------------------------------------------------- fixtures
XSS_T = "<script>alert(1)</script>"
XSS_JS = "');alert(1);//"          # JS-string breakout attempt
RTL = "שלום עולם — RTL title مرحبا بالعالم"
LONG = "L" + "o" * 296 + "ng!"     # 300-char title
EMOJI = "🚀🔥💥 emoji title 🧨🎯"
MULTI = "多字节标题（中文・日本語・한국어）测试"


def mkws(name):
    ws = f"/tmp/tp-fixture-{name}"
    shutil.rmtree(ws, ignore_errors=True)
    os.makedirs(os.path.join(ws, ".taskplane"), exist_ok=True)
    return ws


def wtrace(ws, events, sub=None):
    d = os.path.join(ws, ".tp-work", sub, ".taskplane") if sub else os.path.join(ws, ".taskplane")
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, "trace.jsonl"), "a", encoding="utf-8") as f:
        for e in events:
            f.write((e if isinstance(e, str) else json.dumps(e)) + "\n")


# --- fixture A: loop mid-execute, parallel wave, fix-cycles, contract, XSS in state
wsA = mkws("loop")
stateA = {
    "goal": "Ship the export flow " + XSS_T + " " + RTL,
    "step": "execute", "parallel": True, "current_task": 0,
    "requirement_id": "R-0001", "checkpoints": ["plan"],
    "tasks": [
        {"id": "t1<script>x</script>", "status": "running",
         "scope": ["src/export/**", "src/common/util.py"], "deps": [],
         "fix_cycles": 1, "workspace": wsA + "/.tp-work/t1"},
        {"id": "t2", "status": "passed", "scope": ["src/api/**"],
         "deps": [], "fix_cycles": 0, "workspace": wsA + "/.tp-work/t2"},
        {"id": "t3", "status": "failed", "scope": ["src/ui/**"],
         "deps": ["t1"], "fix_cycles": 2, "workspace": ""},
        {"id": "t4", "status": "pending", "scope": ["docs/**"],
         "deps": ["t1", "t3"], "fix_cycles": 0, "workspace": ""},
    ],
}
_loop.save(wsA, stateA)
contractA = {
    "task_id": "t1'); alert(1);//",
    "read_only": False,
    "coding": {"scope_paths": ["src/export/**"],
               "command_policy": {"deny": ["git push", "rm -rf", "curl", "wget"]}},
    "budget": {"max_actions": 40, "max_cost_usd": 5},
    "activated_at": NOW,
}
tp.atomic_write_json(os.path.join(wsA, ".taskplane", "active_contract.json"), contractA)
json.dump({"t1'); alert(1);//": {"actions": 12, "denies": 2}},
          open(os.path.join(wsA, ".taskplane", "meter.json"), "w"))
evA = [
    {"event": "loop_init", "ts": NOW - 900},
    {"event": "project_init", "ts": NOW - 890},
    {"event": "model_tier", "ts": NOW - 880, "step": "pm", "tier": "standard", "model": "m-std"},
    {"event": "loop_gate", "ts": NOW - 860, "step": "pm", "outcome": "pass", "note": "spec ok " + XSS_T},
    {"event": "model_tier", "ts": NOW - 850, "step": "plan", "tier": "standard", "model": "m-std"},
    {"event": "loop_step", "ts": NOW - 845, "step": "plan", "role": "tp-planner", "dor_ready": True, "dor_warnings": ["scope overlaps t3"], "dor_blockers": []},
    {"event": "loop_gate", "ts": NOW - 830, "step": "plan", "outcome": "pass"},
    {"event": "loop_gate", "ts": NOW - 820, "step": "plan_approval", "outcome": "approved", "note": "LGTM — " + RTL},
    {"event": "lens_route", "ts": NOW - 800, "lenses": [["frontend", "deep"], ["design", "sweep"], [XSS_T, "deep"]]},
    {"event": "loop_wave", "ts": NOW - 780, "ready": ["t1", "t2"]},
    {"event": "loop_claim", "ts": NOW - 770, "task": "t1"},
    {"event": "hook_deny", "ts": NOW - 700, "tool": "Bash", "reason": "out-of-scope write to /etc " + XSS_T},
    {"event": "budget_deny", "ts": NOW - 690, "used": 40, "max": 40},
    {"event": "graph_impact", "ts": NOW - 650, "impacted": 7},
    {"event": "refinement_gate", "ts": NOW - 640, "task": "t1", "score": "4/5"},
    {"event": "kb_recall", "ts": NOW - 620},
    {"event": "decision_recorded", "ts": NOW - 610},
    {"event": "loop_step", "ts": NOW - 600, "step": "execute", "role": "tp-executor", "dor_ready": True, "dor_warnings": [], "dor_blockers": []},
    {"event": "totally_unknown_event", "ts": NOW - 500, "detail": "future schema"},
]
wtrace(wsA, evA)
wtrace(wsA, [{"event": "hook_deny", "ts": NOW - 400, "tool": "Write", "reason": "outside scope"}], sub="t1")
# dispatch queues for _model_rows
dd = os.path.dirname(tp._dispatch_path(wsA, "expected_dispatch.json"))
os.makedirs(dd, exist_ok=True)
json.dump([{"agent": "tp-executor", "ref": "t1", "model_tier": "standard", "model": "m-std"},
           {"agent": "tp-lens", "ref": XSS_T, "model_tier": "fast", "model": None}],
          open(tp._dispatch_path(wsA, "expected_dispatch.json"), "w"))
json.dump([{"agent": "tp-executor", "model": "m-std", "ok": True}],
          open(tp._dispatch_path(wsA, "observed_dispatch.json"), "w"))

# --- fixture B: malformed + oversized trace
wsB = mkws("malformed")
_loop.save(wsB, {"goal": "junk trace robustness", "step": "evaluate",
                 "tasks": [{"id": "t1", "status": "built", "scope": ["a/**"]}]})
junk = [
    '{"event": "loop_init", "ts": 1}',
    'this is not json at all',
    '{"ts": 2, "note": "no event key"}',
    '{"event": "loop_step", "ts": 3, "step": "execute"',  # truncated
    '[1,2,3]',
    '{"event": "hook_deny", "ts": 4, "tool": "Bash", "reason": "x"}',
    '\x00\x01binary garbage\xff',
]
wtrace(wsB, junk)
# oversized: pad past 2MB so tail-read fires
filler = [json.dumps({"event": "loop_step", "ts": 5 + i, "step": "execute",
                      "role": "tp-executor", "pad": "x" * 200}) for i in range(12000)]
wtrace(wsB, filler)

# --- fixture C: exhausted budget (serial contract at ceiling)
wsC = mkws("budget")
_loop.save(wsC, {"goal": "budget wall", "step": "execute", "current_task": 0,
                 "tasks": [{"id": "t1", "status": "running", "scope": ["x/**"]}]})
contractC = {"task_id": "t1", "read_only": False,
             "coding": {"scope_paths": ["x/**"],
                        "command_policy": {"deny": ["git push"]}},
             "budget": {"max_actions": 25}, "activated_at": NOW}
tp.atomic_write_json(os.path.join(wsC, ".taskplane", "active_contract.json"), contractC)
json.dump({"t1": {"actions": 25, "denies": 0}},
          open(os.path.join(wsC, ".taskplane", "meter.json"), "w"))
wtrace(wsC, [{"event": "loop_init", "ts": NOW - 100},
             {"event": "budget_deny", "ts": NOW - 10, "used": 25, "max": 25}])

# --- fixture D: empty fresh store
wsD = mkws("empty")

# --- fixture E: gates — plan_approval (human gate, no contract)
wsE = mkws("gate")
_loop.save(wsE, {"goal": "gate check", "step": "plan_approval",
                 "tasks": [{"id": "t1", "status": "pending", "scope": ["a/**"]},
                           {"id": "t2", "status": "pending", "scope": ["b/**"]}]})
wtrace(wsE, [{"event": "loop_gate", "ts": NOW - 5, "step": "plan_approval", "outcome": ""}])

# --- fixture F: A/B selection with hostile variant names
wsF = mkws("select")
_loop.save(wsF, {"goal": "ab", "step": "selection", "ab": True,
                 "tasks": [{"id": "tA", "variant": "A'-alert" + XSS_JS, "status": "passed", "scope": ["a/**"]},
                           {"id": "tB", "variant": "B", "status": "passed", "scope": ["b/**"]}]})

# ---------------------------------------------------------------- renders
results = {}

# full page render()
outA = dash.render(wsA, out=os.path.join(SCRATCH, "full-page-loop.html"))
htmlA = open(outA, encoding="utf-8").read()
bmeasure("render() full page (loop)", htmlA)

dash.render(wsB, out=os.path.join(SCRATCH, "full-page-malformed.html"))
dash.render(wsD, out=os.path.join(SCRATCH, "full-page-empty.html"))

# widget()
for tag, ws in (("loop", wsA), ("malformed", wsB), ("budget", wsC),
                ("empty", wsD), ("gate", wsE), ("select", wsF)):
    w = dash.widget(ws)
    save(f"widget-{tag}.html", w)
    bmeasure(f"widget({tag})", w)

# widget_paged
for tag, ws in (("loop", wsA), ("malformed", wsB), ("budget", wsC), ("empty", wsD)):
    pages = dash.widget_paged(ws)
    for i, p in enumerate(pages):
        save(f"widget-paged-{tag}-{i}.html", p["html"])
        bmeasure(f"widget_paged({tag}) p{i} '{p['title']}'", p["html"])

# findings: 122 findings incl. adversarial content
random.seed(7)
sevs = ["high"] * 18 + ["med"] * 40 + ["low"] * 40 + ["blocker", "major", "minor",
        "question", "praise"] * 4 + ["wat"] * 2 + ["med", "low"]
findings = []
for i, sv in enumerate(sevs[:122]):
    t = ["Ordinary finding about module boundaries #%d" % i, MULTI, EMOJI, RTL,
         LONG, XSS_T + " in title", "quote's \"and\" <tags> & ampersands"][i % 7]
    findings.append({
        "severity": sv, "domain": ["frontend", "design", XSS_T, "i18n", "a11y"][i % 5],
        "file": "src/mod%d.py" % i, "line": i * 3 + 1,
        "title": t,
        "scenario": ("When the user does X" + " and Y" * (i % 20) + " → boom & <crash> " + XSS_T),
        "fix": "Escape it properly & retest '" + XSS_JS + "'",
        "status": ["open", "fixed", ""][i % 3],
    })
meta = {
    "title": "v2.3.0 whole-codebase review " + XSS_T,
    "subtitle": "122 findings across 26 lenses — " + RTL,
    "tests": "312 passed, 0 failed",
    "clean": ["backend", "sre <b>bold</b>", "privacy"],
    "gate": True,
    "gate_buttons": [
        {"label": "sign off", "prompt": "sign off on the review'" + XSS_JS, "primary": True},
        {"label": "send back", "prompt": "send it back"}],
    "note": "review is the deliverable",
    "lens_coverage": {"frontend": "deep", "design": "deep", "i18n": "sweep"},
    "ws": wsA,
}
ff = dash.render_findings(findings, meta)
save("findings-full.html", ff)
bmeasure("render_findings(122)", ff)

pages = dash.render_findings_paged(findings, meta)
for i, p in enumerate(pages):
    save(f"findings-paged-{i}.html", p["html"])
    bmeasure(f"findings_paged p{i} '{p['title']}'", p["html"])

# empty findings
fe = dash.render_findings([], {"title": "clean review"})
save("findings-empty.html", fe)
bmeasure("render_findings(0)", fe)

# one pathological finding: giant scenario -> forced truncation path
giant = [{"severity": "high", "domain": "frontend", "title": "Giant € " * 40,
          "scenario": ("é" * 9000), "fix": "x", "file": "a.py", "line": 1}] * 6
pg = dash.render_findings_paged(giant, {"title": "giant cards"})
for i, p in enumerate(pg):
    save(f"findings-giant-{i}.html", p["html"])
    bmeasure(f"findings_giant p{i} '{p['title']}'", p["html"])

# headline
h1 = dash.headline_findings(findings, meta)
h2 = dash.headline_findings([findings[0]], {"title": "one"})
h3 = dash.headline_loop(wsC)   # budget-exhausted
h4 = dash.headline_loop(wsA)
h5 = dash.headline_loop(wsD)
save("headlines.txt", "\n\n".join([h1, h2, h3, h4, h5]))

# wave board
lenses = [{"id": "frontend", "name": "Front-end", "status": "done", "findings": 3},
          {"id": "design", "name": "Design", "status": "done", "findings": 0},
          {"id": XSS_T, "name": XSS_T, "status": "running", "findings": None},
          {"id": "i18n", "name": "i18n", "status": "queued", "findings": None},
          {"id": "mobile", "name": "Mobile", "status": "blocked", "findings": None},
          {"id": "one-finding", "name": "One", "status": "done", "findings": 1}]
wv = dash.render_lens_wave(lenses, {"title": "review — lenses running"})
save("wave.html", wv)
bmeasure("render_lens_wave", wv)

# strategy note
note = {"target": "integrations hub " + XSS_T, "north_star": "calm governed dev",
        "alignment": {"verdict": "drift", "note": "partially aligned " + RTL},
        "lenses": [{"name": "Leverage", "read": "high", "note": "x" * 50}],
        "tension": "speed vs governance", "recommendation": "proceed-with-eyes-open",
        "rationale": "because reasons"}
sn = dash.render_strategy_note(note)
save("strategy.html", sn)
bmeasure("render_strategy_note", sn)
save("headline-northstar.txt", dash.headline_northstar(note))

# onboarding
for nxt in ("attach_folder", "init_git", "tp_init", "ready"):
    rep = {"checks": [{"ok": nxt == "ready", "label": "folder", "detail": "d", "hint": "h"},
                      {"ok": False, "label": "git", "detail": "", "hint": "do git init"}],
           "next_action": nxt}
    ob = dash.render_onboarding(rep)
    save(f"onboarding-{nxt}.html", ob)
    bmeasure(f"render_onboarding({nxt})", ob)
    save(f"headline-onboarding-{nxt}.txt", dash.headline_onboarding(rep))

# lens coverage / review graph standalone
save("lens-coverage.html", dash.render_lens_coverage({"frontend": "deep"}))
save("review-graph-empty.html", dash.render_review_graph(wsD))

# plural catalog probes
probes = []
for n in (0, 1, 2):
    probes.append(f"n={n}: " + dash._msg("n_findings", n=n))
    probes.append(f"n={n}: " + dash._msg("n_lenses", n=n))
    probes.append(f"n={n} tasks_planned: " + dash._msg("n_tasks_planned", n=n))
save("plural-probes.txt", "\n".join(probes))

# byte report
with open(os.path.join(SCRATCH, "byte-report.json"), "w") as f:
    json.dump(report, f, indent=1)
over = {k: v for k, v in report.items() if v["over_budget"]}
print("RENDERED", len(report), "surfaces; OVER BUDGET:", len(over))
for k, v in sorted(report.items(), key=lambda kv: -kv[1]["bytes"]):
    flag = " *** OVER ***" if v["over_budget"] else ""
    print(f"{v['bytes']:>7}  {k}{flag}")
